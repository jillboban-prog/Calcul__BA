# calculBA — version Streamlit

Toute l'application tient dans **`streamlit_app.py`** : comptes, jeux de données, saisie, modification et suppression de lignes, import CSV/Excel, statistiques, graphiques, lois de probabilité, exports Excel/CSV.

| Fichier | Rôle | Obligatoire |
|---|---|---|
| `streamlit_app.py` | l'application | oui |
| `requirements.txt` | bibliothèques à installer | oui |
| `.streamlit/config.toml` | couleurs de calculBA (sinon, rouge Streamlit) | non |
| `test_streamlit_app.py` | tests automatiques | non |

---

## Mettre en ligne sur Streamlit Community Cloud

### 1. La base de données Neon (pour ne pas perdre les données)

Streamlit Cloud **efface son disque à chaque redémarrage** de l'application (mise à jour, mise en veille…). Sans base externe, tous les comptes et jeux disparaîtraient.

1. **neon.com**, puis *Sign up* (le plus simple : *Continue with GitHub*).
2. Créez un projet `calculba`, région **AWS Europe Central 1 (Frankfurt)**.
3. **Connect** : copiez l'adresse qui commence par `postgresql://` (elle contient un mot de passe : ne la publiez pas).

### 2. Le dépôt GitHub

Dans votre dépôt (celui que Streamlit utilise déjà), téléversez via *Add file*, puis *Upload files* :
- `streamlit_app.py`
- `requirements.txt`, **en remplaçant** l'ancien : celui de la version FastAPI ne contient pas Streamlit.
- `.streamlit/config.toml` (facultatif)

### 3. L'application sur share.streamlit.io

**Option A, la plus propre : recréer l'application.**
1. Sur share.streamlit.io, ouvrez le menu **⋮** de l'application actuelle, puis **Delete**.
2. **Create app**, puis choisissez le dépôt, la branche `main`, et **Main file path : `streamlit_app.py`**.
3. **Advanced settings**, puis **Secrets** : collez (avec votre adresse Neon) :
   ```toml
   DATABASE_URL = "postgresql://utilisateur:motdepasse@ep-xxxx.eu-central-1.aws.neon.tech/neondb?sslmode=require"
   CALCULBA_INVITE_CODE = "beton-2026"
   ```
   La ligne `CALCULBA_INVITE_CODE` est facultative : avec elle, seules les personnes qui ont le code peuvent créer un compte.
4. **Deploy**. La première installation prend quelques minutes.

**Option B : garder l'application existante.** Si elle est réglée sur `main.py`, copiez tout le contenu de `streamlit_app.py` dans `main.py` sur GitHub. Ajoutez les Secrets dans **⋮**, puis **Settings**, puis **Secrets**, et redémarrez avec **⋮**, puis **Reboot app**.

### 4. Vérifier

- Dans la barre latérale, aucun avertissement jaune « Base temporaire » ne doit apparaître. S'il apparaît, `DATABASE_URL` n'est pas lu : vérifiez les Secrets, puis faites **Reboot app**.
- Créez un compte, importez le fichier d'exemple (bouton sur la page d'import) : vous devez obtenir 54 observations, et dans **Probabilités**, la loi normale classée première.

---

## Sur votre PC

```
py -m pip install -r requirements.txt
py -m streamlit run streamlit_app.py
```
Le navigateur s'ouvre sur http://localhost:8501. Les données vont dans `calculba.db`, à côté du fichier.

---

## Bon à savoir

- **Recharger la page (F5) déconnecte** : c'est le fonctionnement de Streamlit. Les données, elles, restent.
- **Mise en veille** : une application Streamlit gratuite qui ne reçoit pas de visite pendant un certain temps s'endort. Le visiteur suivant voit un bouton pour la réveiller ; elle redémarre en général en moins d'une minute, et les données (chez Neon) ne bougent pas.
- **Limites** : 50 000 lignes et 60 colonnes par jeu, 15 Mo par fichier ; par compte, 100 jeux et 200 000 observations ; 5 créations de compte par heure et par connexion.
- **Mot de passe oublié** : pas d'envoi d'e-mail. Le même `DATABASE_URL` fonctionne avec la version FastAPI de calculBA : `Administrer_en_ligne.bat`, puis **3**, donne un mot de passe temporaire.
- **Mêmes données que la version web** : la version Streamlit utilise exactement les mêmes tables. Une base Neon remplie par l'une est lisible par l'autre. Pour transférer vos données de PC vers Neon : `Administrer_en_ligne.bat`, puis **1**.
