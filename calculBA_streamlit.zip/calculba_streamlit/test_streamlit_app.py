"""Tests de la version Streamlit : fonctions (import du module) puis interface (AppTest).

Lancer :  python -m pytest -q test_streamlit_app.py
Avec DATABASE_URL défini vers une base de TEST PostgreSQL, tout passe sur PostgreSQL (la base est vidée).
"""
import json
import os
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
os.environ.setdefault("CALCULBA_DB", os.path.join(tempfile.mkdtemp(prefix="calculba_st_"), "test.db"))
os.environ.setdefault("CALCULBA_REGISTER_MAX_PER_IP", "100000")
URL = os.environ.get("DATABASE_URL", "")
if URL.startswith("postgres"):
    import psycopg
    with psycopg.connect(URL, autocommit=True) as c:
        c.execute("DROP TABLE IF EXISTS records, datasets, user_sessions, users CASCADE")

sys.path.insert(0, str(HERE))
import pytest  # noqa: E402
import streamlit_app as app  # noqa: E402
from streamlit.testing.v1 import AppTest  # noqa: E402

APP = str(HERE / "streamlit_app.py")
PW = "motdepasse123"


def sample_bytes() -> bytes:
    return app.EXAMPLE_CSV.encode("cp1252")


def make_user(email: str) -> dict:
    try:
        return app.register_user("Ange Test", email, PW, PW, "")
    except app.AppError:
        return app.login_user(email, PW)


# ------------------------------------------------------------------ fonctions

def test_register_login_and_errors():
    u = make_user("st1@example.com")
    assert app.login_user("ST1@example.com", PW)["id"] == u["id"]
    with pytest.raises(app.AppError, match="incorrect"):
        app.login_user("st1@example.com", "mauvais-mot")
    with pytest.raises(app.AppError, match="existe déjà"):
        app.register_user("Ange", "st1@example.com", PW, PW, "")
    with pytest.raises(app.AppError, match="correspondent"):
        app.register_user("Ange", "autre@example.com", PW, "different123", "")
    with pytest.raises(app.AppError, match="10 caractères"):
        app.register_user("Ange", "court@example.com", "court", "court", "")


def test_import_stats_probabilities_match_the_web_version():
    u = make_user("st2@example.com")
    did, n = app.import_dataset(u["id"], "essais_beton.csv", sample_bytes(), "", "Béton")
    assert n == 54
    with app.database() as db:
        ds = app.get_dataset(db, did, u["id"])
        rows = [v for _, v in app.load_records(db, did)]
    s = app.describe(ds["columns"], rows)
    r = s["columns"]["Resistance_MPa"]
    assert (r["count"], r["missing"], r["invalid"], r["invalid_rows"]) == (51, 2, 1, [31])
    assert r["mean"] == pytest.approx(26.9471, abs=1e-4)
    fit = app.fit_distributions(app.profile(["Resistance_MPa"], rows)["Resistance_MPa"]["nums"], "normal")
    assert fit["best"] == "normal" and len([c for c in fit["comparison"] if c["available"]]) == 6
    for key in app.DISTRIBUTIONS:
        assert app.fit_distributions([float(x) for x in range(5, 40, 3)], key)["selected"]["key"] == key


def test_records_edit_and_numeric_check():
    u = make_user("st3@example.com")
    did = app.create_dataset(u["id"], "Poutres", "Structures", "Element\nCharge_kN")
    for e, c in [("P1", "12,5"), ("P2", "15"), ("P3", "18")]:
        app.add_record(did, u["id"], {"Element": e, "Charge_kN": c})
    with pytest.raises(app.AppError, match="non numérique"):
        app.add_record(did, u["id"], {"Element": "P4", "Charge_kN": "abc"})
    with app.database() as db:
        recs = app.load_records(db, did)
    with pytest.raises(app.AppError, match="non numérique"):
        app.update_record(did, u["id"], recs[0][0], {"Element": "P1", "Charge_kN": "abc"})
    app.update_record(did, u["id"], recs[0][0], {"Element": "P1", "Charge_kN": "13"})
    app.delete_record(did, u["id"], recs[2][0])
    with app.database() as db:
        assert [v["Charge_kN"] for _, v in app.load_records(db, did)] == ["13", "15"]
    with pytest.raises(app.AppError, match="deux fois"):
        app.create_dataset(u["id"], "X", "Autre", "a, A")


def test_isolation_quota_export_and_account_deletion(monkeypatch):
    a, b = make_user("st4a@example.com"), make_user("st4b@example.com")
    did = app.create_dataset(a["id"], "Privé", "Autre", "x")
    with app.database() as db, pytest.raises(app.AppError, match="autre compte"):
        app.get_dataset(db, did, b["id"])
    monkeypatch.setattr(app, "MAX_DATASETS_PER_USER", 1)
    with pytest.raises(app.AppError, match="Limite"):
        app.create_dataset(a["id"], "Deux", "Autre", "x")
    app.add_record(did, a["id"], {"x": "=SOMME(A1)"})
    assert app.export_bytes(did, a["id"], "csv-excel").decode("utf-8-sig").splitlines()[1] == "'=SOMME(A1)"
    assert app.export_bytes(did, a["id"], "xlsx")[:2] == b"PK"
    with pytest.raises(app.AppError):
        app.delete_account(a["id"], "mauvais")
    app.delete_account(a["id"], PW)
    with pytest.raises(app.AppError):
        app.login_user("st4a@example.com", PW)


def test_invite_code_and_register_limit(monkeypatch):
    monkeypatch.setattr(app, "INVITE_CODE", "beton-2026")
    with pytest.raises(app.AppError, match="invitation"):
        app.register_user("Invité", "inv@example.com", PW, PW, "faux")
    assert app.register_user("Invité", "inv@example.com", PW, PW, "beton-2026")["email"] == "inv@example.com"
    monkeypatch.setattr(app, "client_ip", lambda: "203.0.113.9")
    t = app.Throttle(2, 3600)
    monkeypatch.setattr(app, "throttles", lambda: {"register": t, "login": app.Throttle(8, 900)})
    app.register_user("R1", "r1@example.com", PW, PW, "beton-2026")
    app.register_user("R2", "r2@example.com", PW, PW, "beton-2026")
    with pytest.raises(app.TooManyAttempts):
        app.register_user("R3", "r3@example.com", PW, PW, "beton-2026")


# ------------------------------------------------------------------ interface

def by_label(widgets, label):
    for w in widgets:
        if w.label == label:
            return w
    raise AssertionError(f"widget « {label} » introuvable parmi {[w.label for w in widgets]}")


def run(at):
    at.run(timeout=60)
    assert not at.exception, [e.value for e in at.exception]
    return at


def logged_in_app(email: str) -> AppTest:
    at = run(AppTest.from_file(APP, default_timeout=60))
    by_label(at.text_input, "Adresse e-mail").input(email)
    by_label(at.text_input, "Mot de passe").input(PW)
    by_label(at.button, "Se connecter").click()
    return run(at)


def test_ui_register_then_home():
    at = run(AppTest.from_file(APP, default_timeout=60))
    assert at.title[0].value == "calculBA"
    by_label(at.text_input, "Nom complet").input("Ange Interface")
    by_label(at.text_input, "Adresse e-mail ").input("ui@example.com")
    pw_fields = [w for w in at.text_input if w.label in ("Mot de passe", "Confirmez le mot de passe") and w.key != "login_password"]
    for w in pw_fields:
        w.input(PW)
    by_label(at.button, "Créer mon compte").click()
    run(at)
    assert at.title[0].value == "Mes jeux de données"


def test_ui_full_dataset_flow():
    u = make_user("ui2@example.com")
    did, _ = app.import_dataset(u["id"], "essais_beton.csv", sample_bytes(), "", "Béton")
    at = logged_in_app("ui2@example.com")
    by_label(at.button, "Ouvrir").click()
    run(at)
    assert at.title[0].value == "essais_beton"

    # Statistiques : avertissement et bouton vers la ligne 31
    at.segmented_control(key="tab").set_value("Statistiques")
    run(at)
    assert any("non numériques" in w.value for w in at.warning)
    by_label(at.button, "Ligne 31").click()
    run(at)
    assert at.session_state["tab"] == "Données"
    edit = [w for w in at.text_input if w.key and w.key.startswith("edit_") and w.label == "Resistance_MPa"][0]
    assert edit.value == "rompu"
    edit.input("abc")
    by_label(at.button, "Enregistrer la ligne n° 31").click()
    run(at)
    assert any("non numérique" in e.value for e in at.error)
    edit = [w for w in at.text_input if w.key and w.key.startswith("edit_") and w.label == "Resistance_MPa"][0]
    edit.input("30,5")
    by_label(at.button, "Enregistrer la ligne n° 31").click()
    run(at)
    at.segmented_control(key="tab").set_value("Statistiques")
    run(at)
    assert not any("non numériques" in w.value for w in at.warning)

    # Graphiques et probabilités s'affichent sans erreur
    at.segmented_control(key="tab").set_value("Graphiques")
    run(at)
    assert len(at.get("vega_lite_chart")) == 4
    at.segmented_control(key="tab").set_value("Probabilités")
    run(at)
    assert at.selectbox(key="p_law").value == "normal"
    for key in app.DISTRIBUTIONS:
        at.selectbox(key="p_law").set_value(key)
        run(at)
        assert not at.error, (key, [e.value for e in at.error])


def test_ui_create_dataset_and_add_record():
    make_user("ui3@example.com")
    at = logged_in_app("ui3@example.com")
    by_label(at.button, "Nouveau jeu").click()
    run(at)
    by_label(at.selectbox, "Partir d'un modèle (facultatif)").set_value("Sols et géotechnique")
    run(at)
    by_label(at.text_input, "Nom du jeu").input("Sondages RN 12")
    by_label(at.button, "Créer le jeu").click()
    run(at)
    assert at.title[0].value == "Sondages RN 12"
    by_label(at.text_input, "Sondage").input("S1")
    by_label(at.text_input, "Profondeur_m").input("1,5")
    by_label(at.button, "Ajouter l'observation").click()
    run(at)
    with app.database() as db:
        ds_id = at.session_state["ds_id"]
        assert [v["Profondeur_m"] for _, v in app.load_records(db, ds_id)] == ["1,5"]


def test_ui_charts_with_awkward_column_names():
    """Apostrophe, point, crochets dans les noms de colonnes : les graphiques doivent rester valides."""
    u = make_user("ui4@example.com")
    did = app.create_dataset(u["id"], "Noms difficiles", "Autre", "N° d'essai\nRésistance.MPa\nCharge [kN]")
    for i in range(1, 13):
        app.add_record(did, u["id"], {"N° d'essai": f"E{i}", "Résistance.MPa": str(20 + i % 5), "Charge [kN]": str(10 + i)})
    at = logged_in_app("ui4@example.com")
    by_label(at.button, "Ouvrir").click(); run(at)
    for tab in ("Graphiques", "Probabilités"):
        at.segmented_control(key="tab").set_value(tab); run(at)
        for chart in at.get("vega_lite_chart"):
            spec = json.loads(chart.proto.spec)
            fields = json.dumps(spec)
            assert "Résistance.MPa:Q" not in fields and "Charge [kN]:Q" not in fields and "d'essai:Q" not in fields
